﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class M1013 : MonoBehaviour {
    public GameObject J1;
    public GameObject J2;
    public GameObject J3;
    public GameObject J4;
    public GameObject J5;
    public GameObject J6;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
